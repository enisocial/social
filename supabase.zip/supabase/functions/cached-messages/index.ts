import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1';
import { corsHeaders } from '../_shared/cors.ts';
import { redis } from '../_shared/redis.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = performance.now();

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    const { conversationId, limit = 50, offset = 0 } = await req.json();

    if (!conversationId) {
      throw new Error('conversationId is required');
    }

    const url = new URL(req.url);
    const bustCache = url.searchParams.get('bustCache') === 'true';
    
    const cacheKey = `messages:v1:${conversationId}:${limit}:${offset}`;
    const cacheTTL = 30; // 30 seconds (messages change frequently)

    // Bust cache if requested (only if Redis is enabled)
    if (bustCache) {
      try {
        await redis.del(cacheKey);
        console.log('🗑️ Cache busted for', cacheKey);
      } catch (redisError) {
        console.log('⚠️ Redis unavailable for cache busting');
      }
    }

    // Try to get from cache (only if Redis is enabled)
    let cachedData = null;
    try {
      cachedData = await redis.get(cacheKey) as { messages: unknown[]; hasMore: boolean } | null;
    } catch (redisError) {
      console.log('⚠️ Redis unavailable, proceeding without cache');
    }

    if (cachedData && !bustCache) {
      const elapsed = performance.now() - startTime;
      console.log(`✅ Cache HIT for ${cacheKey} (${elapsed.toFixed(2)}ms)`);

      return new Response(
        JSON.stringify({
          ...cachedData,
          cached: true,
          performance: { queryTime: elapsed, cacheHit: true }
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
            'X-Cache': 'HIT',
          }
        }
      );
    }

    console.log(`⏳ Cache MISS for ${cacheKey} - fetching from DB`);

    // Verify user is participant in conversation
    const { data: participant, error: partError } = await supabase
      .from('conversation_participants')
      .select('conversation_id')
      .eq('conversation_id', conversationId)
      .eq('user_id', user.id)
      .single();

    if (partError || !participant) {
      throw new Error('Not authorized to access this conversation');
    }

    // Fetch messages
    const { data: messages, error: msgError } = await supabase
      .from('messages')
      .select(`
        *,
        sender:sender_id(id, username, name, avatar_url),
        attachment_metadata,
        read_status(user_id, read_at)
      `)
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .range(offset, offset + limit - 1);

    if (msgError) throw msgError;

    const elapsed = performance.now() - startTime;
    console.log(`✅ DB query completed in ${elapsed.toFixed(2)}ms, storing in cache`);

    const responseData = {
      messages: messages || [],
      hasMore: messages && messages.length === limit,
    };

    // Store in cache (non-blocking, only if Redis is enabled)
    try {
      redis.set(cacheKey, responseData, cacheTTL).catch(err =>
        console.error('Failed to cache messages:', err)
      );
    } catch (redisError) {
      console.log('⚠️ Redis unavailable, skipping cache storage');
    }

    return new Response(
      JSON.stringify({ 
        ...responseData,
        cached: false,
        performance: { queryTime: elapsed, cacheHit: false }
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json',
          'X-Cache': 'MISS',
          'X-Query-Time': `${elapsed.toFixed(2)}ms`,
        } 
      }
    );
  } catch (error) {
    const elapsed = performance.now() - startTime;
    console.error('❌ Error:', error);
    
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        performance: { queryTime: elapsed }
      }),
      { 
        status: 500, 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json',
        } 
      }
    );
  }
});
